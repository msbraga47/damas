# tabuleiro.py
from ia import minimax

class Tabuleiro:
    def __init__(self):
        self.grade = [[0 for _ in range(8)] for _ in range(8)]
        self.configurar_tabuleiro_inicial()
        self.movimentos_sem_avanco = 0 # <-- O nosso Juiz do Empate

    def configurar_tabuleiro_inicial(self):
        for linha in range(8):
            for coluna in range(8):
                if (linha + coluna) % 2 != 0:
                    if linha < 3: self.grade[linha][coluna] = 2 # Pretas
                    elif linha > 4: self.grade[linha][coluna] = 1 # Brancas

    def imprimir_tabuleiro(self):
        for i, linha in enumerate(self.grade):
            print(f"{i} {linha}")

    def mover_peca(self, linha_origem, col_origem, linha_destino, col_destino):
        peca = self.grade[linha_origem][col_origem]
        self.grade[linha_origem][col_origem] = 0
        self.grade[linha_destino][col_destino] = peca
        self.verificar_promocao(linha_destino, col_destino, peca)

    def verificar_promocao(self, linha, coluna, peca):
        if peca == 1 and linha == 0:
            self.grade[linha][coluna] = 3
        elif peca == 2 and linha == 7:
            self.grade[linha][coluna] = 4

    def remover_peca(self, linha, coluna):
        self.grade[linha][coluna] = 0

    def obter_direcoes(self, peca):
        # 1 = Peão Branco (Sobe), 2 = Peão Preto (Desce), 3 e 4 = Damas (Todas)
        if peca == 1: return [(-1, -1), (-1, 1)]
        elif peca == 2: return [(1, -1), (1, 1)]
        else: return [(-1, -1), (-1, 1), (1, -1), (1, 1)]

    def obter_movimentos_simples(self, linha, coluna, jogador):
        movimentos = []
        peca = self.grade[linha][coluna]
        direcoes = self.obter_direcoes(peca)
        
        for dir_linha, dir_col in direcoes:
            nova_linha, nova_col = linha + dir_linha, coluna + dir_col
            if 0 <= nova_linha <= 7 and 0 <= nova_col <= 7:
                if self.grade[nova_linha][nova_col] == 0:
                    movimentos.append({
                        'origem': (linha, coluna), 
                        'destino': (nova_linha, nova_col), 
                        'captura': None
                    })
        return movimentos

    def obter_capturas_imediatas(self, linha, coluna, jogador):
        capturas = []
        peca = self.grade[linha][coluna]
        direcoes = self.obter_direcoes(peca)
        inimigos = [2, 4] if jogador == 1 else [1, 3]
        
        for dir_linha, dir_col in direcoes:
            linha_inimigo = linha + dir_linha
            col_inimigo = coluna + dir_col
            linha_destino = linha_inimigo + dir_linha
            col_destino = col_inimigo + dir_col
            
            if 0 <= linha_destino <= 7 and 0 <= col_destino <= 7:
                if self.grade[linha_inimigo][col_inimigo] in inimigos:
                    if self.grade[linha_destino][col_destino] == 0:
                        capturas.append({
                            'origem': (linha, coluna),
                            'destino': (linha_destino, col_destino),
                            'captura': (linha_inimigo, col_inimigo)
                        })
        return capturas

    def obter_todos_movimentos_legais(self, jogador):
        # Agora o Juiz retorna jogadas de 1 passo só. Mais limpo e fácil de animar!
        movimentos_simples = []
        capturas = []
        
        pecas_do_jogador = [1, 3] if jogador == 1 else [2, 4]
        
        for linha in range(8):
            for coluna in range(8):
                if self.grade[linha][coluna] in pecas_do_jogador:
                    capturas.extend(self.obter_capturas_imediatas(linha, coluna, jogador))
                    movimentos_simples.extend(self.obter_movimentos_simples(linha, coluna, jogador))
                    
        # Se tem captura, é obrigatório (mas sem Lei da Maioria forçando caminho maior)
        if len(capturas) > 0:
            return capturas
        return movimentos_simples
        
    def avaliar_tabuleiro(self):
        """
        O MOTOR AAA: Heurística com Piece-Square Tables (PST).
        A IA agora tem um 'mapa de calor' estratégico na cabeça.
        """
        pontuacao = 0

        # MAPA DE CALOR: Peões valorizam o avanço e as bordas seguras
        # (Lendo de cima para baixo. A linha 0 é onde as Brancas viram Dama)
        PESOS_PEAO_PRETO = [
            [ 0,  0,  0,  0,  0,  0,  0,  0], # Linha 0 (Fundo inimigo - Promoção)
            [ 0,  6,  0,  5,  0,  5,  0,  7], # Linha 1 (Quase dama, bônus alto)
            [ 5,  0,  4,  0,  4,  0,  5,  0], # Linha 2 
            [ 0,  3,  0,  5,  0,  4,  0,  4], # Linha 3 (Meio)
            [ 4,  0,  4,  0,  5,  0,  3,  0], # Linha 4 (Meio)
            [ 0,  2,  0,  2,  0,  2,  0,  3], # Linha 5 
            [ 2,  0,  1,  0,  1,  0,  2,  0], # Linha 6 (Início, valor baixo)
            [ 0,  0,  0,  0,  0,  0,  0,  0]  # Linha 7 (Base das Pretas)
        ]
        
        # O mapa das Brancas é exatamente o mapa das Pretas, só que de ponta cabeça!
        PESOS_PEAO_BRANCO = PESOS_PEAO_PRETO[::-1] 

        # MAPA DE CALOR: Damas querem O CENTRO ABSOLUTO do tabuleiro
        PESOS_DAMA = [
            [ 0,  0,  0,  0,  0,  0,  0,  0],
            [ 0,  2,  0,  3,  0,  3,  0,  0],
            [ 0,  0,  6,  0,  6,  0,  0,  0],
            [ 0,  3,  0, 10,  0,  6,  0,  0], # O Centro (10 pontos extras!)
            [ 0,  0,  6,  0, 10,  0,  0,  0], # O Centro (10 pontos extras!)
            [ 0,  3,  0,  6,  0,  6,  0,  0],
            [ 0,  0,  2,  0,  3,  0,  0,  0],
            [ 0,  0,  0,  0,  0,  0,  0,  0]
        ]

        # Varre o tabuleiro inteiro somando os valores base + os bônus do mapa de calor
        for linha in range(8):
            for coluna in range(8):
                peca = self.grade[linha][coluna]
                if peca == 0: continue

                # O Valor puro da peça (Damas valem quase 3x mais que peões)
                # Valores Positivos = Pretas (IA). Valores Negativos = Brancas (Você).
                if peca == 1: 
                    valor_base = -100
                    bonus_posicao = -PESOS_PEAO_BRANCO[linha][coluna]
                elif peca == 3: 
                    valor_base = -280
                    bonus_posicao = -PESOS_DAMA[linha][coluna]
                elif peca == 2: 
                    valor_base = 100
                    bonus_posicao = PESOS_PEAO_PRETO[linha][coluna]
                elif peca == 4: 
                    valor_base = 280
                    bonus_posicao = PESOS_DAMA[linha][coluna]

                # A nota final daquela peça é a soma de quem ela é + onde ela está
                pontuacao += (valor_base + bonus_posicao)
                
        return pontuacao

    def executar_jogada(self, jogada):
        origem = jogada['origem']
        destino = jogada['destino']
        
        # --- O JUIZ DO EMPATE: Verificando se a jogada "avança" o jogo ---
        peca_movida = self.grade[origem[0]][origem[1]]
        fez_captura = jogada['captura'] is not None
        eh_peao = peca_movida in [1, 2]

        if fez_captura or eh_peao:
            self.movimentos_sem_avanco = 0 # O jogo avançou! Zera o relógio do Juiz.
        else:
            self.movimentos_sem_avanco += 1 # Ninguém comeu e só andou com Dama... Tic Tac.
        # -----------------------------------------------------------------

        self.mover_peca(origem[0], origem[1], destino[0], destino[1])
        
        if jogada['captura']:
            linha_c, col_c = jogada['captura']
            self.remover_peca(linha_c, col_c)
            
    def verificar_empate(self):
        # 40 turnos = 20 jogadas suas + 20 jogadas da IA sem nenhum avanço
        return self.movimentos_sem_avanco >= 40