# interface.py
import flet as ft
import asyncio
import sys
import datetime
from tabuleiro import Tabuleiro
import ia 

def main(page: ft.Page):
    # Configurações Profissionais da Janela
    page.title = "Damas AAA - Edição de Colecionador"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER 
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.window_width = 650
    page.window_height = 850 
    page.bgcolor = "#212121" 
    page.theme_mode = ft.ThemeMode.DARK 
    page.scroll = ft.ScrollMode.AUTO

    # ==========================================
    # TELAS: OPÇÕES E MENU
    # ==========================================
    def mostrar_opcoes(e):
        page.controls.clear()
        titulo_opcoes = ft.Text("⚙️ Opções", size=40, weight=ft.FontWeight.BOLD)
        texto_breve = ft.Text("Configurações de Dificuldade e Loja em breve...", size=16, color=ft.Colors.GREY_400)
        btn_voltar = ft.ElevatedButton("Voltar", icon=ft.Icons.ARROW_BACK, on_click=mostrar_menu)
        coluna_opcoes = ft.Column([titulo_opcoes, texto_breve, btn_voltar], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=20)
        page.add(ft.Container(content=coluna_opcoes, expand=True, alignment=ft.Alignment(0, 0)))
        page.update()

    def mostrar_menu(e=None):
        page.controls.clear() 
        titulo = ft.Text("DAMAS", size=60, weight=ft.FontWeight.W_900, color=ft.Colors.RED_400)
        subtitulo = ft.Text("Edição de Colecionador", size=20, color=ft.Colors.GREY_300, italic=True)
        btn_jogar = ft.ElevatedButton("NOVO JOGO", icon=ft.Icons.PLAY_ARROW_ROUNDED, width=250, height=50, bgcolor=ft.Colors.RED_700, color=ft.Colors.WHITE, on_click=mostrar_jogo)
        btn_opcoes = ft.ElevatedButton("OPÇÕES", icon=ft.Icons.SETTINGS, width=250, height=50, on_click=mostrar_opcoes)
        btn_sair = ft.ElevatedButton("SAIR DO JOGO", icon=ft.Icons.EXIT_TO_APP, width=250, height=50, color=ft.Colors.RED_300, on_click=lambda e: sys.exit())
        menu_col = ft.Column([titulo, subtitulo, ft.Container(height=30), btn_jogar, btn_opcoes, btn_sair], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=15)
        page.add(ft.Container(content=menu_col, expand=True, alignment=ft.Alignment(0, 0)))
        page.update()

    # ==========================================
    # TELA 2: O JOGO (Tabuleiro AAA)
    # ==========================================
    def mostrar_jogo(e=None):
        page.controls.clear()
        jogo = Tabuleiro()
        
        ia.total_posicoes_analisadas_partida = 0
        tempo_inicio_partida = datetime.datetime.now()

        # ==========================================
        # 📱 A MATEMÁTICA RESPONSIVA NATIVA (O SEGREDO)
        # ==========================================
        TAMANHO_TABULEIRO = 480 # Tamanho padrão para PC
        
        # O Flet lê a tela exata do dispositivo (PC ou Celular)
        if page.width > 0 and page.width < 520: 
            TAMANHO_TABULEIRO = page.width - 20 # Encolhe para caber na tela com borda
            
        fator = TAMANHO_TABULEIRO / 480.0 # Cria a proporção (ex: 0.81)

        # Multiplicamos o SEU ALINHAMENTO PERFEITO pelo fator!
        MARGEM_ESQUERDA = 28.7 * fator
        MARGEM_DIREITA  = 27.0 * fator
        MARGEM_TOPO     = 24.0 * fator
        MARGEM_BASE     = 24.0 * fator
        TAMANHO_PECA    = 46 * fator 
        
        LARGURA_JOGAVEL = TAMANHO_TABULEIRO - MARGEM_ESQUERDA - MARGEM_DIREITA
        ALTURA_JOGAVEL = TAMANHO_TABULEIRO - MARGEM_TOPO - MARGEM_BASE
        TAMANHO_CASA_X = LARGURA_JOGAVEL / 8
        TAMANHO_CASA_Y = ALTURA_JOGAVEL / 8
        # ==========================================

        estado = { "turno": 1, "selecionada": None, "jogadas_validas": [], "peca_combo": None }

        texto_status = ft.Text("Seu turno. Clique numa peça.", size=24, color=ft.Colors.WHITE, weight=ft.FontWeight.W_800)
        painel_status = ft.Container(content=texto_status, padding=15, bgcolor=ft.Colors.BLACK54, border_radius=10, margin=ft.Margin.only(bottom=20))
        btn_voltar = ft.ElevatedButton("Desistir e Voltar ao Menu", icon=ft.Icons.ARROW_BACK, color=ft.Colors.RED_300, on_click=mostrar_menu)

        # AQUI USAMOS O TAMANHO RESPONSIVO!
        stack_tabuleiro = ft.Stack(width=TAMANHO_TABULEIRO, height=TAMANHO_TABULEIRO)
        fundo_tabuleiro = ft.Image(src="tabuleiro.png", width=TAMANHO_TABULEIRO, height=TAMANHO_TABULEIRO, fit="fill")
        stack_tabuleiro.controls.append(fundo_tabuleiro)

        area_jogavel = ft.Stack(width=LARGURA_JOGAVEL, height=ALTURA_JOGAVEL, left=MARGEM_ESQUERDA, top=MARGEM_TOPO)
        stack_tabuleiro.controls.append(area_jogavel)

        # ==========================================
        # 🎮 CRIAÇÃO DO POPUP AAA
        # ==========================================
        icone_fim_jogo = ft.Icon(ft.Icons.EMOJI_EVENTS, size=40, color=ft.Colors.AMBER_400)
        texto_resultado = ft.Text("RESULTADO!", size=28, weight=ft.FontWeight.W_900)
        texto_dados_tempo = ft.Text("Tempo: 00:00", size=16, color=ft.Colors.GREY_300)
        texto_dados_ia = ft.Text("Nós da IA: 0", size=16, color=ft.Colors.GREY_300)
        
        container_popup = ft.Container(
            content=ft.Column(
                [
                    ft.Row([icone_fim_jogo, texto_resultado], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Divider(color=ft.Colors.AMBER_400, thickness=1),
                    texto_dados_tempo,
                    texto_dados_ia,
                    ft.ElevatedButton("Voltar ao Menu", icon=ft.Icons.ARROW_BACK, on_click=mostrar_menu)
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12
            ),
            width=320, height=220,
            bgcolor=ft.Colors.BLACK87,
            border_radius=15,
            border=ft.border.all(2, ft.Colors.AMBER_400),
            padding=20,
            opacity=0, 
            scale=0, 
            animate_opacity=ft.Animation(500, ft.AnimationCurve.EASE_OUT_CUBIC),
            animate_scale=ft.Animation(500, ft.AnimationCurve.EASE_OUT_CUBIC),
        )
        
        wrapper_popup = ft.Container(content=container_popup, expand=True, alignment=ft.Alignment(0, 0), visible=False)
        stack_tabuleiro.controls.append(wrapper_popup)
        # ==========================================

        casas_ui = [[None for _ in range(8)] for _ in range(8)]
        pecas_ui = [] 
        lado_borda_fina = ft.BorderSide(1, ft.Colors.BLACK26)
        borda_padrao = ft.Border(top=lado_borda_fina, right=lado_borda_fina, bottom=lado_borda_fina, left=lado_borda_fina)

        for linha in range(8):
            for coluna in range(8):
                casa = ft.Container(
                    width=TAMANHO_CASA_X, height=TAMANHO_CASA_Y,
                    left=coluna * TAMANHO_CASA_X, top=linha * TAMANHO_CASA_Y,
                    bgcolor=ft.Colors.TRANSPARENT, border=borda_padrao,
                    on_click=lambda e, l=linha, c=coluna: processar_clique(l, c)
                )
                casas_ui[linha][coluna] = casa
                area_jogavel.controls.append(casa)

        def criar_desenho_peca(peca_val, linha, coluna):
            arquivo_img = ""
            if peca_val == 1: arquivo_img = "peca_vermelha.png"
            elif peca_val == 2: arquivo_img = "peca_preta.png"
            elif peca_val == 3: arquivo_img = "dama_vermelha.png"
            elif peca_val == 4: arquivo_img = "dama_preta.png"
            else: return None
            # Encolhe a sombra no celular para não ficar exagerada
            sombra_realista = ft.BoxShadow(spread_radius=1, blur_radius=6*fator, color=ft.Colors.BLACK87, offset=ft.Offset(2*fator, 3*fator))
            centro_ajuste_x = (TAMANHO_CASA_X - TAMANHO_PECA) / 2
            centro_ajuste_y = (TAMANHO_CASA_Y - TAMANHO_PECA) / 2
            peca = ft.Container(
                width=TAMANHO_PECA, height=TAMANHO_PECA,
                left=(coluna * TAMANHO_CASA_X) + centro_ajuste_x,
                top=(linha * TAMANHO_CASA_Y) + centro_ajuste_y,
                content=ft.Image(src=arquivo_img, fit="contain"),
                alignment=ft.Alignment(0, 0), shape=ft.BoxShape.CIRCLE, shadow=sombra_realista,   animate_position=ft.Animation(300, ft.AnimationCurve.EASE_OUT_CUBIC)
            )
            peca.data = {"linha": linha, "coluna": coluna, "val": peca_val}
            peca.on_click = lambda e: processar_clique(e.control.data["linha"], e.control.data["coluna"])
            return peca

        for linha in range(8):
            for coluna in range(8):
                val = jogo.grade[linha][coluna]
                if val != 0:
                    peca = criar_desenho_peca(val, linha, coluna)
                    pecas_ui.append(peca)
                    area_jogavel.controls.append(peca)

        def mover_peca_ui(origem, destino, captura):
            peca_movida = None
            centro_ajuste_x = (TAMANHO_CASA_X - TAMANHO_PECA) / 2
            centro_ajuste_y = (TAMANHO_CASA_Y - TAMANHO_PECA) / 2
            for p in pecas_ui:
                if p.data["linha"] == origem[0] and p.data["coluna"] == origem[1]:
                    p.data["linha"] = destino[0]
                    p.data["coluna"] = destino[1]
                    p.top = (destino[0] * TAMANHO_CASA_Y) + centro_ajuste_y
                    p.left = (destino[1] * TAMANHO_CASA_X) + centro_ajuste_x
                    peca_movida = p
                    break
            if captura:
                for p in pecas_ui:
                    if p.data["linha"] == captura[0] and p.data["coluna"] == captura[1]:
                        p.top = -100; p.left = -100; p.opacity = 0; p.data["linha"] = -1; p.data["coluna"] = -1; break
            val_atual = jogo.grade[destino[0]][destino[1]]
            if peca_movida and val_atual in [3, 4] and peca_movida.data["val"] in [1, 2]:
                peca_movida.data["val"] = val_atual
                nova_img = "dama_vermelha.png" if val_atual == 3 else "dama_preta.png"
                peca_movida.content = ft.Image(src=nova_img, fit="contain")

        def atualizar_fundo_casas():
            for linha in range(8):
                for coluna in range(8):
                    casa = casas_ui[linha][coluna]
                    cor_fundo = ft.Colors.TRANSPARENT
                    borda_atual = borda_padrao
                    if estado["selecionada"] == (linha, coluna): cor_fundo = ft.Colors.with_opacity(0.4, ft.Colors.BLUE_ACCENT)
                    for j in estado["jogadas_validas"]:
                        if j['destino'] == (linha, coluna):
                            lado_borda_neon = ft.BorderSide(4, ft.Colors.CYAN_400)
                            borda_atual = ft.Border(top=lado_borda_neon, right=lado_borda_neon, bottom=lado_borda_neon, left=lado_borda_neon)
                    casa.bgcolor = cor_fundo
                    casa.border = borda_atual
            page.update()

        def processar_clique(linha, coluna):
            if wrapper_popup.visible: return
            
            if estado["turno"] != 1: return 
            movimentos = jogo.obter_todos_movimentos_legais(1)
            if estado["peca_combo"]: movimentos = [m for m in movimentos if m['origem'] == estado["peca_combo"] and m['captura'] is not None]
            jogada_escolhida = None
            for j in estado["jogadas_validas"]:
                if j['destino'] == (linha, coluna): jogada_escolhida = j
            if jogada_escolhida:
                jogo.executar_jogada(jogada_escolhida)
                mover_peca_ui(jogada_escolhida['origem'], jogada_escolhida['destino'], jogada_escolhida['captura'])
                fez_captura = jogada_escolhida['captura'] is not None
                estado["selecionada"] = None
                estado["jogadas_validas"] = []
                
                if jogo.verificar_empate():
                    tempo_fim = datetime.datetime.now()
                    duracao = tempo_fim - tempo_inicio_partida
                    minutos, segundos = divmod(int(duracao.total_seconds()), 60)
                    icone_fim_jogo.name = ft.Icons.HANDSHAKE 
                    icone_fim_jogo.color = ft.Colors.BLUE_300
                    texto_resultado.value = "EMPATE!"
                    texto_resultado.color = ft.Colors.WHITE
                    texto_dados_tempo.value = f"Tempo de Jogo: {minutos:02}:{segundos:02}"
                    texto_dados_ia.value = f"O jogo travou após {ia.total_posicoes_analisadas_partida:,} cálculos.".replace(',', '.')
                    container_popup.border = ft.border.all(2, ft.Colors.BLUE_300)
                    container_popup.content.controls[1].color = ft.Colors.BLUE_300 
                    wrapper_popup.visible = True
                    page.update()
                    container_popup.opacity = 1
                    container_popup.scale = 1
                    page.update()
                    texto_status.value = "Acordo de Paz Declarado."
                    texto_status.color = ft.Colors.BLUE_300
                    return
                
                if fez_captura:
                    nova_origem = jogada_escolhida['destino']
                    capturas_futuras = jogo.obter_capturas_imediatas(nova_origem[0], nova_origem[1], 1)
                    if capturas_futuras:
                        estado["peca_combo"] = nova_origem; estado["selecionada"] = nova_origem; estado["jogadas_validas"] = capturas_futuras; texto_status.value = "COMBO! Continue pulando."; texto_status.color = ft.Colors.AMBER_400; atualizar_fundo_casas(); return 
                estado["peca_combo"] = None; estado["turno"] = 2; texto_status.value = "A IA está pensando..."; texto_status.color = ft.Colors.RED_400; atualizar_fundo_casas(); page.run_task(jogar_ia); return

            val_clicado = jogo.grade[linha][coluna]
            if val_clicado in [1, 3]:
                if estado["peca_combo"] and estado["peca_combo"] != (linha, coluna): texto_status.value = "[!] Termine o combo com a peça selecionada!"; texto_status.color = ft.Colors.RED_400
                else: estado["selecionada"] = (linha, coluna); estado["jogadas_validas"] = [m for m in movimentos if m['origem'] == (linha, coluna)]; texto_status.value = "Alvo na mira." if estado["jogadas_validas"] else "Movimento bloqueado."; texto_status.color = ft.Colors.CYAN_300
                atualizar_fundo_casas()
            else:
                if not estado["peca_combo"]: estado["selecionada"] = None; estado["jogadas_validas"] = [] ; texto_status.value = "Seu turno. Pense bem."; texto_status.color = ft.Colors.WHITE; atualizar_fundo_casas()

        async def jogar_ia(e=None):
            await asyncio.sleep(0.5)
            turno_ia_ativo = True
            
            movimentos = jogo.obter_todos_movimentos_legais(2)
            if not movimentos:
                tempo_fim = datetime.datetime.now()
                duracao = tempo_fim - tempo_inicio_partida
                minutos, segundos = divmod(int(duracao.total_seconds()), 60)
                icone_fim_jogo.name = ft.Icons.EMOJI_EVENTS
                icone_fim_jogo.color = ft.Colors.AMBER_400
                texto_resultado.value = "VITÓRIA!"
                texto_resultado.color = ft.Colors.WHITE
                texto_dados_tempo.value = f"Tempo de Jogo: {minutos:02}:{segundos:02}"
                texto_dados_ia.value = f"IA calculou {ia.total_posicoes_analisadas_partida:,} futuros.".replace(',', '.')
                container_popup.border = ft.border.all(2, ft.Colors.AMBER_400)
                container_popup.content.controls[1].color = ft.Colors.AMBER_400 
                wrapper_popup.visible = True
                page.update()
                container_popup.opacity = 1   
                container_popup.scale = 1     
                page.update()
                texto_status.value = "Você Venceu Épicamente!"
                texto_status.color = ft.Colors.GREEN_400
                return

            while turno_ia_ativo:
                pontuacao, melhor_jogada = ia.minimax(jogo, 4, float('-inf'), float('inf'), True, 2)
                if melhor_jogada:
                    jogo.executar_jogada(melhor_jogada)
                    mover_peca_ui(melhor_jogada['origem'], melhor_jogada['destino'], melhor_jogada['captura'])
                    atualizar_fundo_casas()
                    await asyncio.sleep(0.5) 
                    
                    if jogo.verificar_empate():
                        tempo_fim = datetime.datetime.now()
                        duracao = tempo_fim - tempo_inicio_partida
                        minutos, segundos = divmod(int(duracao.total_seconds()), 60)
                        icone_fim_jogo.name = ft.Icons.HANDSHAKE
                        icone_fim_jogo.color = ft.Colors.BLUE_300
                        texto_resultado.value = "EMPATE!"
                        texto_resultado.color = ft.Colors.WHITE
                        texto_dados_tempo.value = f"Tempo de Jogo: {minutos:02}:{segundos:02}"
                        texto_dados_ia.value = f"O jogo travou após {ia.total_posicoes_analisadas_partida:,} cálculos.".replace(',', '.')
                        container_popup.border = ft.border.all(2, ft.Colors.BLUE_300)
                        container_popup.content.controls[1].color = ft.Colors.BLUE_300 
                        wrapper_popup.visible = True
                        page.update()
                        container_popup.opacity = 1
                        container_popup.scale = 1
                        page.update()
                        texto_status.value = "Acordo de Paz Declarado."
                        texto_status.color = ft.Colors.BLUE_300
                        return

                    if melhor_jogada['captura']:
                        destino = melhor_jogada['destino']
                        capturas_futuras = jogo.obter_capturas_imediatas(destino[0], destino[1], 2)
                        if not capturas_futuras: turno_ia_ativo = False
                    else: turno_ia_ativo = False
                else: turno_ia_ativo = False
            estado["turno"] = 1
            
            movimentos_jogador = jogo.obter_todos_movimentos_legais(1)
            if not movimentos_jogador:
                tempo_fim = datetime.datetime.now()
                duracao = tempo_fim - tempo_inicio_partida
                minutos, segundos = divmod(int(duracao.total_seconds()), 60)
                icone_fim_jogo.name = ft.Icons.ERROR_OUTLINE
                icone_fim_jogo.color = ft.Colors.RED_ACCENT_400
                texto_resultado.value = "DERROTA!"
                texto_resultado.color = ft.Colors.WHITE
                texto_dados_tempo.value = f"Tempo de Jogo: {minutos:02}:{segundos:02}"
                texto_dados_ia.value = f"IA calculou {ia.total_posicoes_analisadas_partida:,} futuros.".replace(',', '.')
                container_popup.border = ft.border.all(2, ft.Colors.RED_ACCENT_400)
                container_popup.content.controls[1].color = ft.Colors.RED_ACCENT_400 
                wrapper_popup.visible = True
                page.update()
                container_popup.opacity = 1
                container_popup.scale = 1
                page.update()
                texto_status.value = "A IA te esmagou. 💀"
                texto_status.color = ft.Colors.RED_ACCENT_400
                return
            
            texto_status.value = "Seu turno. Pense bem..."; texto_status.color = ft.Colors.WHITE; atualizar_fundo_casas()

        coluna_jogo = ft.Column(
            [painel_status, stack_tabuleiro, ft.Container(height=20), btn_voltar],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
        tela_principal = ft.Container(content=coluna_jogo, expand=True, alignment=ft.Alignment(0, 0))
        page.add(tela_principal)
        atualizar_fundo_casas()

    mostrar_menu()

ft.run(main, assets_dir="assets")