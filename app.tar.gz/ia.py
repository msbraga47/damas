# ia.py
import copy
import random # A vacina do "Toque Humano"

total_posicoes_analisadas_partida = 0

def minimax(tabuleiro, profundidade, alpha, beta, maximizando, jogador):
    global total_posicoes_analisadas_partida
    total_posicoes_analisadas_partida += 1

    # Condição de parada
    if profundidade == 0:
        return tabuleiro.avaliar_tabuleiro(), None

    movimentos = tabuleiro.obter_todos_movimentos_legais(jogador)
    if not movimentos:
        # Se não tem movimento, perdeu. 
        # A URGÊNCIA: Quanto maior a profundidade (mais rápido acontecer), pior/melhor a nota!
        if maximizando:
            return float('-inf') + profundidade, None # IA perdeu
        else:
            return float('inf') - profundidade, None  # Jogador perdeu

    melhor_jogada = None
    # A MÁGICA HUMANA: Em vez de guardar só 1 jogada, guardamos TODAS as melhores empatadas
    melhores_jogadas_empatadas = []

    if maximizando:
        max_eval = float('-inf')
        for jogada in movimentos:
            tab_copia = copy.deepcopy(tabuleiro)
            tab_copia.executar_jogada(jogada)
            
            # Se for um combo de captura, a IA continua pensando na mesma peça!
            if jogada['captura']:
                capturas_futuras = tab_copia.obter_capturas_imediatas(jogada['destino'][0], jogada['destino'][1], jogador)
                if capturas_futuras:
                    # IA entra em Quiescência (analisa o combo inteiro sem perder profundidade)
                    eval_atual, _ = minimax(tab_copia, profundidade, alpha, beta, True, jogador)
                else:
                    eval_atual, _ = minimax(tab_copia, profundidade - 1, alpha, beta, False, 1 if jogador == 2 else 2)
            else:
                eval_atual, _ = minimax(tab_copia, profundidade - 1, alpha, beta, False, 1 if jogador == 2 else 2)

            # --- A LÓGICA DE ESCOLHA ---
            if eval_atual > max_eval:
                max_eval = eval_atual
                melhores_jogadas_empatadas = [jogada] # Limpa a lista e põe a nova rainha
            elif eval_atual == max_eval:
                melhores_jogadas_empatadas.append(jogada) # Empatou? Entra pra lista de sorteio!

            alpha = max(alpha, eval_atual)
            if beta <= alpha:
                break # Poda Alpha-Beta (Economiza milhares de cálculos)
        
        # Sorteia uma jogada entre as que tiveram a nota máxima!
        if melhores_jogadas_empatadas:
            melhor_jogada = random.choice(melhores_jogadas_empatadas)
            
        return max_eval, melhor_jogada

    else:
        min_eval = float('inf')
        for jogada in movimentos:
            tab_copia = copy.deepcopy(tabuleiro)
            tab_copia.executar_jogada(jogada)
            
            if jogada['captura']:
                capturas_futuras = tab_copia.obter_capturas_imediatas(jogada['destino'][0], jogada['destino'][1], jogador)
                if capturas_futuras:
                    eval_atual, _ = minimax(tab_copia, profundidade, alpha, beta, False, jogador)
                else:
                    eval_atual, _ = minimax(tab_copia, profundidade - 1, alpha, beta, True, 1 if jogador == 2 else 2)
            else:
                eval_atual, _ = minimax(tab_copia, profundidade - 1, alpha, beta, True, 1 if jogador == 2 else 2)

            if eval_atual < min_eval:
                min_eval = eval_atual
                melhores_jogadas_empatadas = [jogada]
            elif eval_atual == min_eval:
                melhores_jogadas_empatadas.append(jogada)

            beta = min(beta, eval_atual)
            if beta <= alpha:
                break
                
        if melhores_jogadas_empatadas:
            melhor_jogada = random.choice(melhores_jogadas_empatadas)
            
        return min_eval, melhor_jogada